package $packagename

class Library {

}
